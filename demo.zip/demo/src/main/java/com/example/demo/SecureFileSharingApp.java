package com.example.demo;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@EnableScheduling
@RestController
@RequestMapping("/files")
public class SecureFileSharingApp {
    private static final String ENCRYPTION_ALGO = "AES";
    private static final int SELF_DESTRUCT_TIME = 60000; // 1 minute for demo
    private static final ConcurrentHashMap<String, Long> fileExpiryMap = new ConcurrentHashMap<>();
    private static final String UPLOAD_DIR = "uploads/";
    private static final SecretKey SECRET_KEY = generateKey();

    public static void main(String[] args) {
        new File(UPLOAD_DIR).mkdir();
        SpringApplication.run(SecureFileSharingApp.class, args); // Fixed class name
    }

    @PostMapping("/upload")
    public String uploadFile(@RequestParam("file") MultipartFile file) throws Exception {
        String fileName = file.getOriginalFilename();
        byte[] encryptedData = encrypt(file.getBytes(), SECRET_KEY);
        Files.write(Paths.get(UPLOAD_DIR + fileName), encryptedData);
        fileExpiryMap.put(fileName, System.currentTimeMillis() + SELF_DESTRUCT_TIME);
        return "File uploaded securely: " + fileName;
    }

    @GetMapping("/download/{fileName}")
    public byte[] downloadFile(@PathVariable String fileName) throws Exception {
        Path filePath = Paths.get(UPLOAD_DIR + fileName);
        if (!Files.exists(filePath)) return null;
        byte[] encryptedData = Files.readAllBytes(filePath);
        return decrypt(encryptedData, SECRET_KEY);
    }

    @GetMapping("/list")
    public List<String> listFiles() {
        try {
            File uploadDir = new File(UPLOAD_DIR);
            String[] fileNames = uploadDir.list();
            List<String> activeFiles = new ArrayList<>();

            if (fileNames != null) {
                for (String fileName : fileNames) {
                    // Only return files that haven't expired
                    if (fileExpiryMap.containsKey(fileName)) {
                        long expiryTime = fileExpiryMap.get(fileName);
                        if (System.currentTimeMillis() < expiryTime) {
                            activeFiles.add(fileName);
                        }
                    }
                }
            }

            return activeFiles;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Scheduled(fixedRate = 5000) // Runs every 5 sec to check file expiry
    public void autoDeleteExpiredFiles() {
        long currentTime = System.currentTimeMillis();
        fileExpiryMap.entrySet().removeIf(entry -> {
            if (currentTime > entry.getValue()) {
                try {
                    Files.deleteIfExists(Paths.get(UPLOAD_DIR + entry.getKey()));
                    System.out.println("Deleted: " + entry.getKey());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return true;
            }
            return false;
        });
    }

    private static SecretKey generateKey() {
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance(ENCRYPTION_ALGO);
            keyGen.init(256);
            return keyGen.generateKey();
        } catch (Exception e) {
            throw new RuntimeException("Error generating encryption key", e);
        }
    }

    private static byte[] encrypt(byte[] data, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGO);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(data);
    }

    private static byte[] decrypt(byte[] data, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGO);
        cipher.init(Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(data);
    }

    @PostMapping("/verify")
    public String verifyIntegrity(@RequestParam("file") MultipartFile file, @RequestParam("hash") String hash) throws Exception {
        byte[] fileBytes = file.getBytes();
        String fileHash = hashSHA256(fileBytes);
        return fileHash.equals(hash) ? "File is intact" : "File has been tampered";
    }

    private static String hashSHA256(byte[] data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data);
        return Base64.getEncoder().encodeToString(hash);
    }
}